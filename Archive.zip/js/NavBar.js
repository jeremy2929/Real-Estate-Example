import React from "react"
import { Link } from "react-router"
import $ from 'jquery'

var height = window.screen.height
var width = window.screen.width
if (height > 700 && width > 1200) {
  var navBar = $(".nav_bar")
  $(window).scroll(function() {
    if( $(this).scrollTop() > 620 ) {
      $(".nav_bar").addClass("nav_bar_scrolled");
      $('.contact_page').css('margin-top','6em')
    } else {
      $(".nav_bar").removeClass("nav_bar_scrolled")
      $('.contact_page').css('margin-top','1em')

    }
  });
}

// <Link to="/ContactMe" className="nav_options">CONTACT</Link>


export default React.createClass({
  getInitialState(){
    return {
      imgSrc: '/styles/facebook.png'
    }
  },
   handleMouseOver() {
     this.setState({
       imgSrc: '/styles/facebook_name.png'
     })
   },
   handleMouseOut() {
     this.setState({
       imgSrc: '/styles/facebook.png'
     })
   },
   contactMe(){

   },
  render(){
    if (height > 700 && width > 1200) {
      return (
        <nav className="nav_bar">
          <article className="nav_left">
            <h1 className="nav_name_left">Agent Name</h1>
          </article>
          <article className="nav_middle">
              <a href="" onMouseEnter={this.handleMouseOver} onMouseLeave={this.handleMouseOut}>
              <img className="facebook" ref="facebookImage" src={this.state.imgSrc}/>
            </a>
          </article>
          <article className="nav_right">
              <ul className="nav_content_right">
                <li>
                  <a className="nav_options" href="#">
                    HOME
                  </a>
                </li>
                <li>
                  <Link to="/Services" className="nav_options">SERVICES</Link>
                </li>
                <li>
                  <Link to="/AboutMe" className="nav_options">ABOUT</Link>
                </li>
                <li>
                  <p className="nav_options" onClick={this.contactMe}>CONTACT</p>
                </li>
              </ul>
          </article>
        </nav>
      )
    } else {
      // <article className="nav_left">
      //   <h1 className="nav_name_left">Agent Name</h1>
      // </article>
      return (
        <nav className="nav_mobile_wrapper">
          <article className="nav_left">
            <ul className="nav_content_right">
              <li>
                <a className="nav_options" href="#">
                  HOME
                </a>
              </li>
              <li>
                <Link to="/Services" className="nav_options">SERVICES</Link>
              </li>
            </ul>
          </article>
          <article className="nav_middle">
              <a href="" onMouseEnter={this.handleMouseOver} onMouseLeave={this.handleMouseOut}>
              <img className="facebook" ref="facebookImage" src={this.state.imgSrc}/>
            </a>
          </article>
          <article className="nav_right">
              <ul className="nav_content_right">
                <li>
                  <Link to="/AboutMe" className="nav_options">ABOUT</Link>
                </li>
                <li>
                  <Link to="/ContactMe" className="nav_options">CONTACT</Link>
                </li>
              </ul>
          </article>
        </nav>
      )
    }
  }
})
