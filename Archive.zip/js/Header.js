import React from "react"
import {Link} from "react-router"
var createReactClass = require('create-react-class');

export default React.createClass({
  render() {
    return(
      <header className="header_bar">
        <div>

        </div>
      </header>
    )
  }
})
